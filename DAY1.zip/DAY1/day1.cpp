#include<iostream>
using namespace std;

void large()
{   int n;
    cout<<"enter size of array"<<endl;
    cin>>n;
    int arr[n];
    
    int MAX=arr[0];
cout<<"Enter the Elements"<<endl;
    for(int i=0;i<n;i++){
    cin>>arr[i];
        if(arr[i]>MAX){
            MAX =arr[i];
        }
    }
    cout<<"LARGEST ELEMENT = "<<MAX<<endl;
}
int main(){
    large();
    return 0;
}

//5 LINEAR SEARCH 
#include<iostream>
using namespace std;

int LinearSearch(int *arr, int n, int key){
  for(int i=0 ; i<n; i++){
    if(arr[i]==key){
        return i;
    }
  }
  return -1;
}
int main()
{
    
    int arr[]={5,7,4,15,8,3,9,14,2};
    int n = sizeof(arr)/sizeof(int);
    cout<<"the index is: "<<LinearSearch(arr,n,14);
    return 0;
}

//Reeverse the array

#include<iostream>
using namespace std;

int printarr(int *arr, int n)
{
  for(int i=0; i<n; i++){
    cout<<arr[i]<<",";
  }
  cout<<endl;
}
int main()
{
  int arr[]={1,2,3,4,5};
  int n = sizeof(arr)/sizeof(int);
  int start=0;
  int end = n-1;

  while(start<end)
  {
    int temp = arr[start];
    arr[start] = arr[end];
    arr[end] = temp;
    start++;
    end--;
  }
  printarr(arr,n);
}

//Binary Search

#include<iostream>
using namespace std;

int linSearch(int *arr, int n, int key){

  int start = 0, end = n-1;

  while(start<=end){
    int mid = (start+end)/2;

    if(arr[mid]==key){
      return mid;
    }
    else if(arr[mid]<key){
      start = mid+1;
    }
    else{
      end = mid-1;
    }
  }
  return -1;
}
int main()
{
  int arr[]={9,8,5,2,7,12,18,19,20};
  int n = sizeof(arr)/sizeof(int);

  cout<<linSearch(arr,n,19)<<endl;

  return 0;
}