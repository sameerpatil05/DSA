#include<iostream>
using namespace std;

int fact(){
    int f = 1;
    int n;
    cout<<"Enter the number";
    cin>>n;

    for(int i=1; i<=n; i++ ){
        f *= i;

    
    }
    cout<<f;
}
int main()
{
 fact();
 return 0;
}