//BRUTE FOCE APROACH

#include<iostream>
using namespace std;

int MaxSubArray(int *arr, int n)
{
     int maxSub=INT_MIN;
    for(int start=0; start<n ;start++){
        for(int end = start; end < n ; end++){
            int currSum=0;
            for(int i = start ; i <= end;i++){
                 currSum += arr[i];
            }
              cout<<currSum<<",";
              maxSub = max(maxSub,currSum);
        }
         cout<<endl;
    }
    cout<<"Maximum Subarray is: "<<maxSub<<endl;
};

int main()
{
    int arr[] = {2,-3,6,-5,4,2};

    int n = sizeof(arr)/sizeof(int);

    MaxSubArray(arr,n);

    return 0;
}

//Opyimised brute force Approach

#include<iostream>
using namespace std;

int MaxSubArray(int *arr, int n)
{
     int maxSub=INT_MIN;
    for(int start=0; start<n ;start++){
        int currSum=0;
        for(int end = start; end < n ; end++){
              currSum += arr[end];
        }
             maxSub = max(maxSub,currSum);
         
    }
    cout<<"Maximum Subarray is: "<<maxSub<<endl;
};

int main()
{
    int arr[] = {2,-3,6,-5,4,2};

    int n = sizeof(arr)/sizeof(int);

    MaxSubArray(arr,n);

    return 0;
}

//KADANE's ALGO
#include<iostream>
using namespace std;

int MaxSubArray(int *arr, int n)
{
     int maxSub=INT_MIN;
    
        int currSum=0;
        for(int i=0;i<n;i++){
              currSum += arr[i];
            maxSub = max(maxSub,currSum);
         
            if(currSum<0){
                currSum=0;
            }
    }
    cout<<"Maximum Subarray is: "<<maxSub<<endl;
};

int main()
{
    int arr[] = {2,-3,6,-5,4,2};

    int n = sizeof(arr)/sizeof(int);

    MaxSubArray(arr,n);

    return 0;
}