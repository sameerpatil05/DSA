#include<iostream>
using namespace std;

int print(int arr[], int n){
    for(int i=0;i<n;i++){
        cout<<arr[i]<<" ";
    }
    cout<<endl;
}

int bubbleSort(int arr[], int n){
    for(int i=0; i<n-1; i++){
        for(int j=0; j<n-i-1; j++){
            if(arr[j]>arr[j+1]){
                swap(arr[j],arr[j+1]);
            }
        }
    }
    print(arr,n);
}

int selectionSort(int arr[], int n){
   for(int i=0;i<n-1;i++){
   int minIDX = i;

   for(int j = i+1; j<n;j++){
    if(arr[j]<arr[minIDX]){
        minIDX = j;
    }
    swap(arr[i],arr[minIDX]);
   }
   } 
   print(arr,n);
}

int InsertionSort(int arr[], int n){
    for(int i=1;i<n;i++){
        int curr = arr[i];
        int prev = i-1;

        while(prev>=0 && arr[prev]>curr){
            swap(arr[prev],arr[prev+1]);
            prev--;
        }
        arr[prev+1] = curr;
    }
    print(arr,n);
}

int CountingSort(int arr[], int n){
    int freq[10000];
    int minVal = INT_MAX;
    int maxVal = INT_MIN;

    for(int i=0;i<n;i++){
        freq[arr[i]]++;
        minVal = min(minVal, arr[i]);
        maxVal = max(maxVal, arr[i]);
    }
    for(int i=minVal, j=0; i<maxVal; i++){
        while(freq[i]>0){
            arr[j++]=i;
            freq[i]--;
        }
    }
    print(arr,n);
}
int main()
{
    int arr[10]= {3, 6, 2, 1, 8, 7, 4, 5, 3, 1};
    
    CountingSort(arr,10);

    return 0;
}