#include<iostream>
using namespace std;

int print(int arr[], int n){
    for(int i=0;i<n;i++){
        cout<<arr[i]<<" ";
    }
    cout<<endl;
}

int CountingSort(int arr[], int n){
    int freq[100000];
    int minVal = INT_MAX;
    int maxVal = INT_MIN;

    for(int i=0; i<n; i++){
        freq[arr[i]]++;
        minVal = min(minVal, arr[i]);
        maxVal = max(maxVal, arr[i]);
    }

    for(int i = minVal, j=0; i<=maxVal; i++){
        while(freq[i]>0){
            arr[j++]=i;
            freq[i]--;
        }
    }
    print(arr, n);
 }

int main()
{
    int arr[6]= {3,7,0,3,5,1};
    
    CountingSort(arr,6);

    return 0;
}