#include<iostream>
using namespace std;

int print(int arr[], int n){
    for(int i=0;i<n;i++){
        cout<<arr[i]<<" ";
    }
    cout<<endl;
}

int InsertionSort(int arr[], int n){

    for(int i=0; i<n; i++){
          int curr = arr[i];
          int prev = i-1;

          while(prev >= 0 && arr[prev] > curr){
                swap(arr[prev], arr[prev+1]);
                prev--;
          }
          arr[prev+1] = curr;
    }
    print(arr, n);
 }

int main()
{
    int arr[6]= {3,7,0,3,5,1};
    
    InsertionSort(arr,6);

    return 0;
}