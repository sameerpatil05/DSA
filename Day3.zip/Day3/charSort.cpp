#include<iostream>
using namespace std;

int print(char arr[], int n){
    for(int i=0;i<n;i++){
        cout<<arr[i]<<" ";
    }
    cout<<endl;
}

int charSort(char arr[], int n){
     
    for(int i=0; i<n; i++){
        int curr = arr[i];
        int prev = i-1;

        while(prev >= 0 && arr[prev] < curr){
            swap(arr[prev],arr[prev+1]);
            prev--;
        }
        arr[prev+1]=curr;
    }
    print(arr, n);
 }

int main()
{
    char ch[6]= {'f','t','z','s','w','p'};
    
    charSort(ch,6);

    return 0;
}